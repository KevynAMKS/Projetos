import streamlit as st
import pandas as pd
from datetime import date
import plotly.express as px

def get_data():
    path = '../2_bases_tratadas/base_tratada.csv'
    return pd.read_csv(path, sep=';')

df = get_data()

df.idade_pessoa = df.idade_pessoa.astype('int')

st.sidebar.header('MENU')
conner = st.sidebar.selectbox('Escolha o gráfico',['Etnia','Profissão','Mês','Município','Créditos'])

idade = df['idade_pessoa'].unique().tolist()
qntd_linhas = st.sidebar.slider('Selecione a idade de você dejesa ver nos gráficos',min_value=min(idade),max_value=max(idade),value=(min(idade),max(idade)))
mask = (df['idade_pessoa'].between(*qntd_linhas))
number_of_result = df[mask].shape[0]
selmin,selmax=qntd_linhas
dfres = df.loc[(df['idade_pessoa'] >= selmin)&(df['idade_pessoa'] <= selmax)]

if conner == 'Etnia':
    def grafico(df):
        fig  =  px.bar(dfres,'cor_pele') 
        return st.plotly_chart(fig)
    grafico(dfres)
    st.text('''Como podemos ver no gráfico, se analisarmos a maior amplitude de idade podemos 
perceber que as mulheres brancas são as maiores vítimas de feminicídio. Porém, se 
pegarmos até os 31 anos, percebemos que a situação inverte, sendo as maiores vítimas 
de feminicídio as mulheres pardas. O encontro das etnias acontece com 32 anos.''')
    st.markdown(f'*Resultados: {number_of_result}*')
    st.dataframe(dfres)

elif conner == 'Profissao':
    def grafico(df):
        fig = px.bar(dfres, 'profissao')
        return st.plotly_chart(fig)
    grafico(dfres)
    st.text('''Ao analisar o gráfico, podemos perceber que a maioria das vitimas preferiram não 
informar sua profissão, seguido por “Prenda doméstica” e “Outros”. ''')

elif conner == 'Mês':
    def grafico(df):
        fig = px.histogram(dfres,'mês_estatistica')
        return st.plotly_chart(fig)
    grafico(dfres)
    st.text('''O mês que teve a maior quantidade foi novembro com 22 casos e o menor foi abril, 
com 10. O período que teve a maior queda e manteve a estabilidade de menores casos 
foi de abril a junho, com uma queda de 9 casos. Já o período mais estável e com 
maiores casos foi de outubro a dezembro.''')

elif conner == 'Município':
     def grafico(df):
        fig = px.scatter(dfres,x='municipio_circunscricao',y='idade_pessoa',color='municipio_circunscricao')
        return st.plotly_chart(fig)
     grafico(dfres)
     st.text('''Embora São Paulo e Osasco estejam na mesma cor, podemos perceber que a amplitude 
de idade dos casos de São Paulo varia de 18 aos 77 anos, enquanto Osasco é de 
19 anos até 39 anos. Em comparação com o município de Nova Granada, que possui uma 
vitima menor de 1 ano de idade.''')

else:
    st.title('Os participantes do trio são:')
    st.text('Gregory Henrique   RA: 2202566')
    st.text('Rebeca Cleto  RA: 2203471')
    st.text('Kevyn Alexsander  RA: 2202760')
